/*
 ============================================================================
 Name        : cli.c
 Author      : marcosallustio
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */
#include<sys/types.h>
#include<sys/socket.h>
#include<stdio.h>
#include<stdlib.h>
#include<netinet/in.h>
#include<netdb.h>
#include <unistd.h>
#include<string.h>
#include<strings.h>
#include <arpa/inet.h>
#include "protocol.h"

void error(const char *msg)
{
	perror(msg);
	exit(1);
}

int main(int argc, char *argv[])
{
	int sockfd, portno, n;
	struct sockaddr_in serv_addr;
	struct hostent *server;

	char buffer[256];
	if(argc<2)
	{
		printf("No address entered\n");
		printf("Enter the address: 127.0.0.1\n");

		exit(1);

	}
	else if(argc<3 && argc>=2)
	{
		fprintf(stderr,"usage %s hostname port\n",argv[0]);
		exit(1);
	}
	portno = atoi(argv[2]);
	sockfd= socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd <0)
		error("Error opening socket");

	server= gethostbyname(argv[1]);
	if(server == NULL)
	{
		fprintf(stderr, "Error, no such host");
	}
		bzero((char *)&serv_addr, sizeof(serv_addr));
		serv_addr.sin_family=AF_INET;

		bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
		serv_addr.sin_port=htons(portno);
		if(connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr))<0)
			error("Connection failed");
		struct t_op op;
		printf("Insert the operation in the format [Type of operation] [Number] [Number]\n");
				printf("Indicate the type of operation with the corresponding number:\n");
				printf("To close the client enter the number 5 followed equally by both numbers\n");
				printf("1)+\n2)-\n3)*\n4)/\n5)=\n");
S:
				bzero(buffer,256);
				n=read(sockfd,buffer,255);
				if(n<0)
					error("Error on reading");
				printf("Server - %s\n",buffer);
				scanf("%d %d %d",&op.choice,&op.num1,&op.num2);
				write(sockfd,&op.choice,sizeof(int));
				write(sockfd,&op.num1,sizeof(int));
				write(sockfd,&op.num2,sizeof(int));


				if(op.choice == 5)
					goto Q;

				read(sockfd,&op.ans,sizeof(int));
				printf("Server - The answer is: %d\n",op.ans);

				if(op.choice != '=')
					goto S;

Q: if(op.choice==5)
   printf("Client disconnection..\n");
close(sockfd);
return 0;

	}

