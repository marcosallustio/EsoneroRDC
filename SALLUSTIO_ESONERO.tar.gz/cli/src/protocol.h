/*
 * protocol.h
 *
 *  Created on: 24 nov 2021
 *      Author: marco
 */

#ifndef PROTOCOL_H_
#define PROTOCOL_H_
#define QLEN 5

typedef struct t_op {
	int num1,num2,ans,choice;
}t_op;

#endif /* PROTOCOL_H_ */
