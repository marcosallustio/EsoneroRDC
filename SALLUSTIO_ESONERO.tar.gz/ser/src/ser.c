/*
 ============================================================================
 Name        : server.c
 Author      : marcosallustio
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */
#include<sys/types.h>
#include<sys/socket.h>
#include<stdio.h>
#include<stdlib.h>
#include<netinet/in.h>
#include<netdb.h>
#include <unistd.h>
#include<string.h>
#include<strings.h>
#include <arpa/inet.h>
#include "protocol.h"

void error(const char *msg)
{
	perror(msg);
	exit(1);
}

int main(int argc, char *argv[])
{
	if(argc<2)
		{
			printf("No ports entered\n");
			printf("Inserts the port number 9898\n");

			exit(1);
		}
	int sockfd, newsockfd, portno, n;
	char buffer[255];

	struct sockaddr_in serv_addr, cli_addr;
	socklen_t clilen;

	sockfd= socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd<0)
	{
		error("Error opening socket");
	}

	bzero((char *) &serv_addr, sizeof(serv_addr));
	portno= atoi(argv[1]);

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr=INADDR_ANY;
	serv_addr.sin_port=htons(portno);



	if(bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr))<0)
		error("Bind() failed");

	listen(sockfd, QLEN);
	clilen= sizeof(cli_addr);
	Q: newsockfd=accept(sockfd, (struct sockaddr *)&cli_addr, &clilen);
	printf("Waiting for client connection...\n");
	printf("Connection established with 127.0.0.1: %d\n",(int) ntohs(serv_addr.sin_port));
	if(newsockfd<0)
	{
		error("Error on accept()");
	}

	struct t_op op;

S:
		n= write(newsockfd,"Insert the operation: ",strlen("Insert the operation:"));
		if(n<0)
			error("Error on writing");
		read(newsockfd, &op.choice, sizeof(int));
		read(newsockfd, &op.num1, sizeof(int));
		read(newsockfd, &op.num2, sizeof(int));
		char* type_op;
		if(op.choice==1)
		{
			type_op="ADDITION";
		}
		else if(op.choice==2)
		{
			type_op="SUBTRACTION";
		}
		else if(op.choice==3)
		{
			type_op="MULTIPLICATION";

		}
		else if(op.choice==4)
		{
			type_op="DIVISION";

		}
		else if(op.choice==5)
		{
			type_op="CLOSE";

		}
		printf("Client - The operation is: %d %d %d ---> %s \n", op.choice,op.num1,op.num2,type_op);


		switch(op.choice)
			{
			case 1:
				op.ans=add(op.num1,op.num2);
				break;

			case 2:
				op.ans=sub(op.num1,op.num2);
				break;

			case 3:
				op.ans=mult(op.num1,op.num2);
				break;

			case 4:
				op.ans=division(op.num1,op.num2);
				break;

			case 5:
				goto Q;
				break;
			}

		write(newsockfd, &op.ans, sizeof(int));
			if(op.choice != 5)
				goto S;





return 0;
}

int add(int a, int b)
{
 return a+b;
}

int sub(int a, int b)
{
 return a-b;
}

int mult(int a, int b)
{
 return a*b;
}

int division(int a, int b)
{
 return a/b;
}
